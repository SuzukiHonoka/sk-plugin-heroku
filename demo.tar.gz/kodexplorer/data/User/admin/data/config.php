<?php exit;?>{
    "listType": "icon",
    "listSortField": "name",
    "listSortOrder": "up",
    "fileIconSize": "80",
    "animateOpen": "1",
    "soundOpen": "1",
    "theme": "win10",
    "wall": "http:\/\/desk.fd.zol-img.com.cn\/t_s1920x1200\/g5\/M00\/02\/05\/ChMkJlbKyS-ILd5bABBh6PJr4QwAALIKwAAAAAAEGIA800.jpg",
    "fileRepeat": "replace",
    "recycleOpen": "1",
    "resizeConfig": "{\"filename\":250,\"filetype\":80,\"filesize\":80,\"filetime\":215,\"editorTreeWidth\":200,\"explorerTreeWidth\":200}"
}