/* ----------------------------------
Template by: JoJunIori for Moem.cc
Copy prohibited
本模板模板由笨蛋乔制作
未经许可禁止擅自盗用,修改及仿制
http://flan.moem.cc
----------------------------------*/
if (typeof window.moon_palace !== "object") window.moon_palace = {};

(function () {

var anime = {};

anime.playExitAnime = function (element) {
	var anime = element.attr("exit-anime");
	if (anime) element.removeClass(anime);
	if (anime) element.addClass(anime);
};

window.moon_palace.anime = anime;
}) ();
